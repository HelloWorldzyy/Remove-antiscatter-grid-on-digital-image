
// MainFrm.h : CMainFrame ��Ľӿ�
//

#pragma once
#include "RangeSlider.h"
#include "UI/SplitterMultiWnd.h"

enum  DisplayViewType { ShowView = 0, ControlView };
#define SCRX(x) (int)((x)*GetSystemMetrics(SM_CXSCREEN))
#define SCRY(y) (int)((y)*GetSystemMetrics(SM_CYSCREEN))

class CMYTESTAView;
class CContrlFormView;
class CMainFrame : public CFrameWndEx
{
	
protected: // �������л�����
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// ����
public:
	CStatusBar m_childStatusBar;
	CRangeSlider m_ctrlSlider;
	BOOL m_bSliderCreated;
	CContrlFormView *m_pContrlView;
	CMYTESTAView *m_pShowView;
// ����

protected:
	CSplitterMultiWnd m_wndSplitter;

public:
	CContrlFormView * GetContrlView();
	CMYTESTAView * GetShowView();
	 
// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// ʵ��
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // �ؼ���Ƕ���Ա
	CToolBar          m_wndToolBar;
	CStatusBar        m_wndStatusBar;

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnViewCustomize();
	afx_msg LRESULT OnToolbarCreateNew(WPARAM wp, LPARAM lp);
	 
	DECLARE_MESSAGE_MAP()
	 
	virtual void RecalcLayout(BOOL bNotify = TRUE);
 
	afx_msg void OnSize(UINT nType, int cx, int cy);
	 
	 
	BOOL LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd * pParentWnd, CCreateContext * pContext);
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext * pContext);
	BOOL SetSplitterInfo(int iCol, int iCxIdeal, int iCxMin);
public:
	 
};


