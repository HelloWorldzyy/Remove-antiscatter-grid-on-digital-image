// CtrlFormView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MYTESTA.h"
#include "CtrlFormView.h"
 
#include "MYTESTAView.h"
#include "MainFrm.h"
#include "MYTESTADoc.h"

// CCtrlFormView

IMPLEMENT_DYNCREATE(CCtrlFormView, CFormView)

CCtrlFormView::CCtrlFormView()
	: CFormView(IDD_DIALOG_CTRLFORM)
	, m_width(50)
	,m_level(0)
	, iMin(0)
	, iMax(3000)
	 
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CCtrlFormView::~CCtrlFormView()
{
}

void CCtrlFormView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_width);
	DDX_Text(pDX, IDC_CW, m_level);
	//DDV_MinMaxInt(pDX, m_iEdtRange, 0, 99999);
//	DDX_Control(pDX, IDC_SCROLLBAR_WinWidth, m_WidthScrollbar);
}

BEGIN_MESSAGE_MAP(CCtrlFormView, CFormView)
	ON_WM_HSCROLL()
 //	ON_NOTIFY(NM_THEMECHANGED, IDC_SCROLLBAR_WinWidth, &CCtrlFormView::OnHScroll)
	 
ON_BN_CLICKED(IDC_Toosmall, &CCtrlFormView::OnBnClickedToosmall)
ON_BN_CLICKED(IDC_Toobig, &CCtrlFormView::OnBnClickedToobig)
ON_BN_CLICKED(IDC_LITTLEBO, &CCtrlFormView::OnBnClickedLittlebo)
ON_BN_CLICKED(IDC_Gaosiquzao, &CCtrlFormView::OnBnClickedGaosiquzao)
ON_BN_CLICKED(IDC_OriginalImg, &CCtrlFormView::OnBnClickedOriginalimg)
ON_BN_CLICKED(IDC_OpenImage, &CCtrlFormView::OnBnClickedOpenimage)
ON_BN_CLICKED(IDC_SaveImg, &CCtrlFormView::OnBnClickedSaveimg)
ON_BN_CLICKED(IDC_BUTTON2, &CCtrlFormView::MeanFilter)
ON_BN_CLICKED(IDC_Flip, &CCtrlFormView::OnBnClickedFlip)
END_MESSAGE_MAP()


// CCtrlFormView ���

#ifdef _DEBUG
void CCtrlFormView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CCtrlFormView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG

void CCtrlFormView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	//CFormView::OnInitDialog();
	/**/ 
	//CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
	//CMYTESTAView *pShowView = pMain->GetShowView();
	 
	//CMYTESTADoc *pDoc = pShowView->GetDocument();
	CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
	CMYTESTADoc *pDoc = (CMYTESTADoc *)pMain->GetActiveDocument();
	CScrollBar* pScrollBar = (CScrollBar*)GetDlgItem(IDC_SCROLLBAR_TEST);
	//pScrollBar->SetScrollRange(pDoc->minValue, pDoc->maxValue,true);//�����ƶ���λ��Ϊ0����100��
	pScrollBar->SetScrollRange(pDoc->minValue, pDoc->maxValue);
	pScrollBar->SetScrollPos(0);
	 
	CScrollBar* pScrollBar1 = (CScrollBar*)GetDlgItem(IDC_SCROLLBAR_CK);
	pScrollBar1->SetScrollRange(pDoc->minValue, pDoc->maxValue);//�����ƶ���λ��Ϊ0����100��
	pScrollBar1->SetScrollPos(100);
	 
	iMin = pDoc->minValue;
	iMax = pDoc->maxValue;
//	return TRUE;
}
// CCtrlFormView ��Ϣ��������
 
void CCtrlFormView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CWnd *pa = this->GetDlgItem(IDC_SCROLLBAR_CK);
	CWnd *pb = this->GetDlgItem(IDC_SCROLLBAR_TEST);
	int iPos = nPos;
	if (pScrollBar!=NULL)
	{  
	int TempPos = pScrollBar->GetScrollPos();
	 
	 
	 CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
     CMYTESTAView *pShowView = pMain->GetShowView();
	if (pa == pScrollBar) {
		switch (nSBCode)
		{
		case SB_THUMBTRACK://�϶�����
			if (iPos < TempPos && iPos >= iMin)
			{
				pScrollBar->SetScrollPos(iPos, TRUE);

			}
			else if (iPos > TempPos && iPos <= iMax)
			{
				pScrollBar->SetScrollPos(iPos, TRUE);

			}
			m_width = pScrollBar->GetScrollPos();

			m_maxValue = m_level + m_width / 2;
			m_minValue = m_level - m_width / 2;

			 if (pShowView != NULL)
			 	{
			 		pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
			 	}
			UpdateData(FALSE);
			break;
			//case SB_THUMBPOSITION://�϶�����
			//	pScrollBar->SetScrollPos(iPos, FALSE);
			//	
			//	break;
		case SB_LINELEFT://����ϱߵļ�ͷ
			if (TempPos > iMin)
			{
				pScrollBar->SetScrollPos(TempPos - 1, TRUE);
				m_width = pScrollBar->GetScrollPos();
				m_maxValue = m_level + m_width / 2;
				m_minValue = m_level - m_width / 2;

				if (pShowView != NULL)
				{
					pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
				}
				UpdateData(FALSE);
			}
			break;
		case SB_LINERIGHT://����±ߵļ�ͷ
			if (TempPos < iMax)
			{
				pScrollBar->SetScrollPos(TempPos + 1, TRUE);
				m_width = pScrollBar->GetScrollPos();
				m_maxValue = m_level + m_width / 2;
				m_minValue = m_level - m_width / 2;

				if (pShowView != NULL)
				{
					pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
				}
				UpdateData(FALSE);
			}
			break;
		case SB_PAGELEFT://����������Ϸ��հ�
			if (TempPos > iMin)
			{
				pScrollBar->SetScrollPos(TempPos - 1, TRUE);
				m_width = pScrollBar->GetScrollPos();
				m_maxValue = m_level + m_width / 2;
				m_minValue = m_level - m_width / 2;

				if (pShowView != NULL)
				{
					pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
				}
				UpdateData(FALSE);
			}
			break;
		case SB_PAGERIGHT://����������·��հ�
			if (TempPos < iMax)
			{
				pScrollBar->SetScrollPos(TempPos + 1, TRUE);
				m_width = pScrollBar->GetScrollPos();
				m_maxValue = m_level + m_width / 2;
				m_minValue = m_level - m_width / 2;

				if (pShowView != NULL)
				{
					pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
				}
				UpdateData(FALSE);
			}
			break;
		case SB_ENDSCROLL:
			m_width = pScrollBar->GetScrollPos();
			m_maxValue = m_level + m_width / 2;
			m_minValue = m_level - m_width / 2;

			if (pShowView != NULL)
			{
				pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
			}

			UpdateData(FALSE);
			break;
		default:
			break;
		}
	}
	if (pb == pScrollBar) {
		switch (nSBCode)
		{
		case SB_THUMBTRACK://�϶�����
			if (iPos < TempPos && iPos >= iMin)
			{
				pScrollBar->SetScrollPos(iPos, TRUE);

			}
			else if (iPos > TempPos && iPos <= iMax)
			{
				pScrollBar->SetScrollPos(iPos, TRUE);

			}
			m_level = pScrollBar->GetScrollPos();

			m_maxValue = m_level + m_width / 2;
			m_minValue = m_level - m_width / 2;

			if (pShowView != NULL)
			{
				pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
			}
			UpdateData(FALSE);
			break;
			//case SB_THUMBPOSITION://�϶�����
			//	pScrollBar->SetScrollPos(iPos, FALSE);
			//	
			//	break;
		case SB_LINELEFT://����ϱߵļ�ͷ
			if (TempPos > iMin)
			{
				pScrollBar->SetScrollPos(TempPos - 1, TRUE);
				m_level = pScrollBar->GetScrollPos();

				m_maxValue = m_level + m_width / 2;
				m_minValue = m_level - m_width / 2;

				if (pShowView != NULL)
				{
					pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
				}
				UpdateData(FALSE);
			}
			break;
		case SB_LINERIGHT://����±ߵļ�ͷ
			if (TempPos < iMax)
			{
				pScrollBar->SetScrollPos(TempPos + 1, TRUE);
				m_level = pScrollBar->GetScrollPos();

				m_maxValue = m_level + m_width / 2;
				m_minValue = m_level - m_width / 2;

				if (pShowView != NULL)
				{
					pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
				}
				UpdateData(FALSE);
			}
			break;
		case SB_PAGELEFT://����������Ϸ��հ�
			if (TempPos > iMin)
			{
				pScrollBar->SetScrollPos(TempPos - 1, TRUE);
				m_level = pScrollBar->GetScrollPos();

				m_maxValue = m_level + m_width / 2;
				m_minValue = m_level - m_width / 2;

				if (pShowView != NULL)
				{
					pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
				}
				UpdateData(FALSE);
			}
			break;
		case SB_PAGERIGHT://����������·��հ�
			if (TempPos < iMax)
			{
				pScrollBar->SetScrollPos(TempPos + 1, TRUE);
				m_level = pScrollBar->GetScrollPos();

				m_maxValue = m_level + m_width / 2;
				m_minValue = m_level - m_width / 2;

				if (pShowView != NULL)
				{
					pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
				}
				UpdateData(FALSE);
			}
			break;
		case SB_ENDSCROLL:
			m_level = pScrollBar->GetScrollPos();

			m_maxValue = m_level + m_width / 2;
			m_minValue = m_level - m_width / 2;

			if (pShowView != NULL)
			{
				pShowView->PostMessage(WM_WinWidthLevel, (WPARAM)m_maxValue, (LPARAM)m_minValue);
			}
			UpdateData(FALSE);
			break;
		default:
			break;
		}
	}}
	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);

}

 



void CCtrlFormView::OnBnClickedToosmall()
{
	CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
	CMYTESTAView *pShowView = pMain->GetShowView();// TODO: �ڴ����ӿؼ�֪ͨ�����������
	pShowView->ToSmall();
}


void CCtrlFormView::OnBnClickedToobig()
{
	CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
	CMYTESTAView *pShowView = pMain->GetShowView();// TODO: �ڴ����ӿؼ�֪ͨ�����������
	pShowView->ToBig();// TODO: �ڴ����ӿؼ�֪ͨ�����������
}


void CCtrlFormView::OnBnClickedLittlebo()
{
	CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
	CMYTESTAView *pShowView = pMain->GetShowView();// TODO: �ڴ����ӿؼ�֪ͨ�����������
	pShowView->OnXiaobo();
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}


void CCtrlFormView::OnBnClickedGaosiquzao()
{
	CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
	CMYTESTAView *pShowView = pMain->GetShowView();// TODO: �ڴ����ӿؼ�֪ͨ�����������
	pShowView->OnGaosi();
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}


void CCtrlFormView::OnBnClickedOriginalimg()
{
	CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
	CMYTESTAView *pShowView = pMain->GetShowView();// TODO: �ڴ����ӿؼ�֪ͨ�����������
	pShowView->goback();// TODO: �ڴ����ӿؼ�֪ͨ�����������
}


void CCtrlFormView::OnBnClickedOpenimage()
{
	 
	CFileDialog filedlg(TRUE, _T("all"), NULL, OFN_HIDEREADONLY, _T("ALL file(*.*)|*.*||"), NULL);
	filedlg.m_ofn.lpstrTitle = _T("Load Image");

	if (filedlg.DoModal() == IDOK)
	{
		CString filename = filedlg.GetPathName();
		 
		CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
		CMYTESTADoc *pDoc = (CMYTESTADoc *)pMain->GetActiveDocument();

		if (pDoc != NULL)
		{
			 pDoc->OnOpenDocument((LPCTSTR)filename);
			 CMYTESTAView *pShowView = pMain->GetShowView();
			 pShowView-> OnInitialUpdate();
			 pShowView->Invalidate();
			 OnInitialUpdate();
		}

	}
	//pDoc->OnOpenDocument();// TODO: �ڴ����ӿؼ�֪ͨ�����������
}


void CCtrlFormView::OnBnClickedSaveimg()
{
	CFileDialog filedlg(FALSE, _T("all"), NULL, OFN_HIDEREADONLY, _T("ALL file(*.*)|*.*||"), NULL);
	filedlg.m_ofn.lpstrTitle = _T("Load Image");

	if (filedlg.DoModal() == IDOK)
	{
		CString filename = filedlg.GetPathName();

		CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
		CMYTESTADoc *pDoc = (CMYTESTADoc *)pMain->GetActiveDocument();

		if (pDoc != NULL)
		{
			pDoc->SaveImage(filename);
		}

	}	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}


void CCtrlFormView::MeanFilter()
{

	CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
	CMYTESTADoc *pDoc = (CMYTESTADoc *)pMain->GetActiveDocument();
	pDoc->meanfilter();	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}


void CCtrlFormView::OnBnClickedFlip()
{
		CMainFrame *pMain = (CMainFrame *)AfxGetMainWnd();
	CMYTESTADoc *pDoc = (CMYTESTADoc *)pMain->GetActiveDocument();
	pDoc->flips();// TODO: �ڴ����ӿؼ�֪ͨ�����������
}
