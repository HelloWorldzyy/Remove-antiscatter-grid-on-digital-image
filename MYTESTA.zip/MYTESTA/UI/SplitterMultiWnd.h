#pragma once

#include <map>
using namespace std;

// CSplitterMultiWnd
#define PEN_WIDTH 2
class CSplitterMultiWnd : public CSplitterWnd
{
	DECLARE_DYNAMIC(CSplitterMultiWnd)

public:
	CSplitterMultiWnd();
	virtual ~CSplitterMultiWnd();

	int   AddDynamicView(int iRow, int iCol, int iViewID, CRuntimeClass * pViewClass, CCreateContext* pContext);
	void  ShowDynamicView(int iRow, int iCol, int iViewID);
	CWnd* GetView(int iViewID);
	BOOL  ShowSplitter(BOOL bVisible);

public:

	
protected:
	void ShowViewWindow(int iRow, int iCol, int iViewID);
	int  HideViewWindow(int iRow, int iCol);

private:
	
	int GetCurrentView(int iViewNumber);
	int GetViewNumber(int iRow, int iCol);

protected:
	map<int, CWnd*> m_mapViews;		// view id, view window
	map<int, int> m_mapCurrentView;	// view number, current view id
	BOOL m_Visible;


protected:
	DECLARE_MESSAGE_MAP()
public:
	BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	BOOL OnMouseWheel(UINT fFlags, short zDelta, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	void StartTracking(int ht);
	void OnDrawSplitter(CDC* pDC, ESplitType nType,const CRect& rectArg);

};


