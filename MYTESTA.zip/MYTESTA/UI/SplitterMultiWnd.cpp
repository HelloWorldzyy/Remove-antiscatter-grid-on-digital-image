// SplitterMultiWnd.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SplitterMultiWnd.h"


// CSplitterMultiWnd

IMPLEMENT_DYNAMIC(CSplitterMultiWnd, CSplitterWnd)
CSplitterMultiWnd::CSplitterMultiWnd()
{
	m_cxBorderShare = 4;
	m_cxSplitterGap = m_cySplitterGap = 2;
//	m_cxBorder = m_cyBorder = 4;
	m_Visible = FALSE;
}

CSplitterMultiWnd::~CSplitterMultiWnd()
{
}


BEGIN_MESSAGE_MAP(CSplitterMultiWnd, CSplitterWnd)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()

BOOL CSplitterMultiWnd::ShowSplitter(BOOL bVisible)
{
	m_Visible = bVisible;
	return m_Visible;
}

// CSplitterMultiWnd ��Ϣ��������
int CSplitterMultiWnd::AddDynamicView(int iRow, int iCol, int iViewID, CRuntimeClass * pViewClass, CCreateContext* pContext)
{

	// create the new view, if fail, set the previous view current 
	if (CreateView(iRow, iCol, pViewClass, CSize(0,0), pContext) == 0)
	{
		return -1;
	}

	// get and store the new view
	CWnd* pNewWnd = GetPane(iRow, iCol);
	m_mapViews[iViewID] = pNewWnd;

	m_mapCurrentView[GetViewNumber(iRow, iCol)] = iViewID;
	HideViewWindow(iRow, iCol);

	return 1;

}

void CSplitterMultiWnd::ShowDynamicView(int iRow, int iCol, int iViewID)
{
	// switch views
	HideViewWindow(iRow, iCol);
	ShowViewWindow(iRow, iCol, iViewID);
}

int CSplitterMultiWnd::HideViewWindow(int iRow, int iCol)
{

	//int iViewID = m_mapCurrentView[GetViewNumber(iRow, iCol)];
	int iViewID = GetCurrentView(GetViewNumber(iRow, iCol));
	CWnd* cwnd = GetView(iViewID);

	if (cwnd != NULL)
	{
		cwnd->SetDlgCtrlID(0);
		cwnd->ShowWindow(SW_HIDE);	
	}
	return 1;
}

void CSplitterMultiWnd::ShowViewWindow(int iRow, int iCol, int iViewID)
{
	CWnd * pView = GetView(iViewID);
	if (pView != NULL)
	{
		int i = IdFromRowCol(iRow, iCol);
		pView->SetDlgCtrlID(IdFromRowCol(iRow, iCol));
		pView->ShowWindow(SW_SHOW);

		m_mapCurrentView[GetViewNumber(iRow, iCol)] = iViewID;
	}
}

int CSplitterMultiWnd::GetViewNumber(int iRow, int iCol)
{
	return (iRow * this->GetColumnCount()) + iCol;
}

CWnd* CSplitterMultiWnd::GetView(int iViewID)
{
	map<int, CWnd*>::iterator iter;

	iter = m_mapViews.find(iViewID);
	if(iter == m_mapViews.end())
		return NULL;
	else
		return (*iter).second;
}

int CSplitterMultiWnd::GetCurrentView(int iViewNumber)
{
	map<int, int>::iterator iter;

	iter = m_mapCurrentView.find(iViewNumber);
	if(iter == m_mapCurrentView.end())
		return -1;
	else
		return (*iter).second;
}


void CSplitterMultiWnd::OnDrawSplitter(CDC *pDC, ESplitType nType, const CRect &rectArg)
{
	if (pDC == NULL)
	{
		RedrawWindow(rectArg, NULL, RDW_INVALIDATE|RDW_NOCHILDREN);
		return;
	}
	if(m_Visible)
	{
		CSplitterWnd::OnDrawSplitter(pDC,nType,rectArg);
		return;
	}
	ASSERT_VALID(pDC);
	CRect rect = rectArg;
	CPen WhitePen;
	WhitePen.CreatePen(PS_SOLID, PEN_WIDTH, GetSysColor(COLOR_WINDOW));
	pDC->SelectObject(&WhitePen);
	pDC->Rectangle(rect);
}

void CSplitterMultiWnd::StartTracking(int ht)
{
	if(m_Visible)
		CSplitterWnd::StartTracking(ht);
}


void CSplitterMultiWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	if(m_Visible)
		CSplitterWnd::OnLButtonDown(nFlags, point);
}

void CSplitterMultiWnd::OnMouseMove(UINT nFlags, CPoint point)
{
	if(m_Visible)
		CSplitterWnd::OnMouseMove(nFlags, point);
}

BOOL CSplitterMultiWnd::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	if(m_Visible)
		return CSplitterWnd::OnSetCursor(pWnd, nHitTest, message);
	return TRUE;
}

BOOL CSplitterMultiWnd::OnMouseWheel(UINT fFlags, short zDelta, CPoint point)
{
	if(m_Visible)
		return CSplitterWnd::OnMouseWheel(fFlags, zDelta, point);
	return TRUE;
}