
// MainFrm.cpp : CMainFrame ���ʵ��
//

#include "stdafx.h"
#include "MYTESTA.h"
#include"MYTESTAView.h"
#include"CtrlFormView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWndEx)
const int  iMaxUserToolbars = 10;
const UINT uiFirstUserToolBarId = AFX_IDW_CONTROLBAR_FIRST + 40;
const UINT uiLastUserToolBarId = uiFirstUserToolBarId + iMaxUserToolbars - 1;

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWndEx)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_CUSTOMIZE, &CMainFrame::OnViewCustomize)
	 
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, &CMainFrame::OnToolbarCreateNew)
	    
	 
END_MESSAGE_MAP()
 

static UINT indicators[] =
{
	ID_SEPARATOR,           // ״̬��ָʾ��
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
	ID_INDICATOR_WIN_MIN,
	ID_INDICATOR_WIN_MAX,
	ID_INDICATOR_WIN_WIDTH,
	ID_INDICATOR_WIN_LEVEL,
};
// CMainFrame ����/����

CMainFrame::CMainFrame()
{
	m_bSliderCreated = FALSE;// TODO: �ڴ����ӳ�Ա��ʼ������	// TODO: �ڴ����ӳ�Ա��ʼ������
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("δ�ܴ���״̬��\n");
		return -1;      // δ�ܴ���
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators) / sizeof(UINT));

	return 0;
}
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	return TRUE;
}

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG

void CMainFrame::RecalcLayout(BOOL bNotify)
{
	// TODO:  �ڴ�����ר�ô����/����û���

	CFrameWnd::RecalcLayout(bNotify);

	if (m_childStatusBar.m_hWnd)
	{
		if (!m_bSliderCreated)
			 ;
		else
			m_ctrlSlider.Invalidate();
	}

}

 

 



 
void CMainFrame::OnViewCustomize()
{
	CMFCToolBarsCustomizeDialog* pDlgCust = new CMFCToolBarsCustomizeDialog(this, TRUE /* ɨ��˵�*/);
	pDlgCust->EnableUserDefinedToolbars();
	pDlgCust->Create();
}

LRESULT CMainFrame::OnToolbarCreateNew(WPARAM wp, LPARAM lp)
{
	LRESULT lres = CFrameWndEx::OnToolbarCreateNew(wp, lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
	return lres;
}

BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext)
{
	// ���ཫִ�������Ĺ���

	if (!CFrameWndEx::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}


	// Ϊ�����û������������Զ��尴ť
	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	for (int i = 0; i < iMaxUserToolbars; i++)
	{
		CMFCToolBar* pUserToolbar = GetUserToolBarByIndex(i);
		if (pUserToolbar != NULL)
		{
			pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
		}
	}

	return TRUE;
}


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	if (m_wndSplitter.CreateStatic(this, 1, 2) == NULL)
		return FALSE;

	m_wndSplitter.AddDynamicView(0, 0, ShowView, RUNTIME_CLASS(CMYTESTAView), pContext);

	m_wndSplitter.AddDynamicView(0, 1, ControlView, RUNTIME_CLASS(CCtrlFormView), pContext);

	m_pShowView = (CMYTESTAView *)m_wndSplitter.GetView(ShowView);

	m_pContrlView = (CContrlFormView *)m_wndSplitter.GetView(ControlView);

	m_wndSplitter.ShowDynamicView(0, 0, ShowView);
	m_wndSplitter.ShowDynamicView(0, 1, ControlView);

	int Width2 = 300;
	int Width1 = GetSystemMetrics(SM_CXSCREEN) - Width2;

	SetSplitterInfo(0, Width1, SCRX(0.1));
	SetSplitterInfo(1, Width2, SCRX(0.1));

	m_wndSplitter.ShowSplitter(TRUE);

	return TRUE;
	//return CFrameWndEx::OnCreateClient(lpcs, pContext);
}

BOOL CMainFrame::SetSplitterInfo(int iCol, int iCxIdeal, int iCxMin)
{
	m_wndSplitter.SetColumnInfo(iCol, iCxIdeal, iCxMin);
	m_wndSplitter.RecalcLayout();
	return TRUE;
}

void CMainFrame::OnSize(UINT nType, int cx, int cy)
{
	CFrameWndEx::OnSize(nType, cx, cy);

	if (nType == SIZE_MAXIMIZED)
	{
		//������������С����Ҫ�������¼�
		if (m_pShowView != NULL)
		{
			int Width2 = 300;
			int Width1 = cx - Width2;;

			SetSplitterInfo(0, Width1, SCRX(0.1));
			SetSplitterInfo(1, Width2, SCRX(0.1));

		}
	}
	if (nType == SIZE_RESTORED)
	{
		//���������ӻ�ԭʱ��Ҫ�������¼�
		if (m_pShowView != NULL)
		{
			int Width2 = 300;
			int Width1 = cx - Width2;;

			SetSplitterInfo(0, Width1, SCRX(0.1));
			SetSplitterInfo(1, Width2, SCRX(0.1));

		}
	}
}

CContrlFormView * CMainFrame::GetContrlView()
{
	return m_pContrlView;
}

CMYTESTAView * CMainFrame::GetShowView()
{
	return m_pShowView;
}


 