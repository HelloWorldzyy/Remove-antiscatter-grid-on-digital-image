#pragma once
#include "afxwin.h"



// CCtrlFormView ������ͼ

class CCtrlFormView : public CFormView
{
	DECLARE_DYNCREATE(CCtrlFormView)

protected:
	CCtrlFormView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CCtrlFormView();

public:
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_CTRLFORM };
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	HICON m_hIcon;
	virtual void OnInitialUpdate();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	//afx_msg void  OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	DECLARE_MESSAGE_MAP()
public:
	int m_width;
	int m_level;
	int iMin;
	int iMax;
	int m_maxValue, m_minValue;
	CScrollBar m_WidthScrollbar;
	CScrollBar m_levelScrollbar;
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
//	afx_msg void OnVScrol(NMHDR *pNMHDR, LRESULT *pResult);
	 
	afx_msg void OnBnClickedToosmall();
	afx_msg void OnBnClickedToobig();
	afx_msg void OnBnClickedLittlebo();
	afx_msg void OnBnClickedGaosiquzao();
	afx_msg void OnBnClickedOriginalimg();
	afx_msg void OnBnClickedOpenimage();
	afx_msg void OnBnClickedSaveimg();
	afx_msg void MeanFilter();
	afx_msg void OnBnClickedFlip();
};


