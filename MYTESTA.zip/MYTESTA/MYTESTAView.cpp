
// MYTESTAView.cpp : CMYTESTAView ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "MYTESTA.h"
#endif

#include "MYTESTADoc.h"
#include "MYTESTAView.h"
#include  "..\Dll_Test1\Dll_Test1.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMYTESTAView

IMPLEMENT_DYNCREATE(CMYTESTAView, CScrollView)

BEGIN_MESSAGE_MAP(CMYTESTAView, CScrollView)
	// ��׼��ӡ����
	ON_MESSAGE(WM_WinWidthLevel, &CMYTESTAView::OnProcessWidthlevel)
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_BIG, &CMYTESTAView::ToBig)
	ON_COMMAND(ID_SMALL, &CMYTESTAView::ToSmall)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_COMMAND(32771, &CMYTESTAView::OnXiaobo)
	ON_MESSAGE(MultiReturn, &CMYTESTAView::OnPostProcess)
	ON_COMMAND(Gaosi, &CMYTESTAView::OnGaosi)
 
	 
END_MESSAGE_MAP()

// CMYTESTAView ����/����

CMYTESTAView::CMYTESTAView()
{
	// TODO: �ڴ˴����ӹ������

}

CMYTESTAView::~CMYTESTAView()
{
}
void CMYTESTAView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	CMYTESTADoc *pDoc = GetDocument();
	CSize sizeTotal;
	if (!pDoc->m_pPic.IsNull())
	{

		sizeTotal.cx = pDoc->m_pPic.GetWidth();
		sizeTotal.cy = pDoc->m_pPic.GetHeight();

	}
	else
	{
		sizeTotal.cx = 2500;
		sizeTotal.cy = 2500;
	}
	SetScrollSizes(MM_TEXT, sizeTotal);
}

BOOL CMYTESTAView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	return CView::PreCreateWindow(cs);
}

// CMYTESTAView ����

void CMYTESTAView::OnDraw(CDC* pDC)
{
	CMYTESTADoc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	CRect rect;
	GetClientRect(&rect);
	if (rect.Width() <= 1 || rect.Height() <= 1)
		return;

	if (!pDoc->m_pPic.IsNull())
	{
		pDoc->m_pPic.Draw(pDC->m_hDC, 0, 0);

 
	}
 
}


// CMYTESTAView ��ӡ

BOOL CMYTESTAView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// Ĭ��׼��
	return DoPreparePrinting(pInfo);
}

void CMYTESTAView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: ���Ӷ���Ĵ�ӡǰ���еĳ�ʼ������
}

void CMYTESTAView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: ���Ӵ�ӡ����е���������
}


// CMYTESTAView ���

#ifdef _DEBUG
void CMYTESTAView::AssertValid() const
{
	CView::AssertValid();
}

void CMYTESTAView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMYTESTADoc* CMYTESTAView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMYTESTADoc)));
	return (CMYTESTADoc*)m_pDocument;
}
#endif //_DEBUG

LRESULT  CMYTESTAView::OnProcessWidthlevel(WPARAM wParam, LPARAM lParam)
{
	int maxV = (int)wParam;
	int minV = (int)lParam;
	CMYTESTADoc* pDoc = GetDocument();
	 
	pDoc->MatFloatToCImage(maxV, minV);

	Invalidate();

	return 0;

}
// CMYTESTAView ��Ϣ��������
void  CMYTESTAView::ToBig()
{
	CMYTESTADoc* pDoc = GetDocument();
	pDoc->m_srcfloatw = pDoc->m_srcfloatw * 2;
	pDoc->m_srcfloath = pDoc->m_srcfloath * 2;
	pDoc->MatFloatToCImage(pDoc->m_srcMaxValue, pDoc->m_srcMinValue);
	OnInitialUpdate();
	Invalidate();

}
void  CMYTESTAView::ToSmall()
{
	CMYTESTADoc* pDoc = GetDocument();
	pDoc->m_srcfloatw = pDoc-> m_srcfloatw / 2;
	pDoc->m_srcfloath = pDoc->m_srcfloath / 2;
	pDoc->MatFloatToCImage(pDoc->m_srcMaxValue, pDoc->m_srcMinValue);
	OnInitialUpdate();
	Invalidate();

}

UINT CMYTESTAView::Thread1(void *param)
{

	CMYTESTAView *pt = (CMYTESTAView*)param;
	CMYTESTADoc* pDoc = pt->GetDocument();
	Mat a = pDoc->m_srcRGB;
	Mat I(a.rows, a.cols, CV_32F, Scalar::all(0));
	for (int i = 0; i < a.rows; i++)
	{
		ushort *ps = a.ptr<ushort>(i);
		float *ds = I.ptr<float>(i);
		for (int j = 0; j < a.cols; j++)
		{
			ds[j] = ps[j];
		}
	}
	I = pDoc->flips(I);
	if (I.empty())
	{

		return -1;
	}
	float GRID_FRE = 4;			//դ��Ƶ��
	float SAMP_FRE = 7.194f;	//����Ƶ��

	float GrayLeftEdge = 0;
	float GrayRightEdge = 0;
	Mat Content_image(I, Rect(20, 20, I.cols - 40, I.rows - 40));
	Mat Result_image(Content_image.rows, Content_image.cols, CV_32F, Scalar::all(0));	//
	Mat normalMat(Content_image.rows, Content_image.cols, CV_32F, Scalar::all(0));



	//
	  CGaussianFilterProcess gfp;
	  gfp.Normalization(Content_image, normalMat,&GrayRightEdge, &GrayLeftEdge);


	Result_image = gfp.Show_2DWsubIm(normalMat, GRID_FRE, SAMP_FRE);

	Mat inormalMat = gfp.iNormalization(Result_image, GrayRightEdge, GrayLeftEdge);

	Mat finalMat(I.rows, I.cols, I.type(), Scalar::all(0));
	Mat finalMat_ROI(finalMat, Rect(20, 20, I.cols - 40, I.rows - 40));
	inormalMat.copyTo(finalMat_ROI);
	finalMat.copyTo(pDoc->srcfloat);


	pt->PostMessage(MultiReturn, (WPARAM)0, (LPARAM)0);
	AfxMessageBox(_T("�������"));
 

	return 0;
}




void CMYTESTAView::OnXiaobo()
{
	AfxBeginThread(Thread1, this);// TODO: �ڴ�����������������
}
LRESULT  CMYTESTAView::OnPostProcess(WPARAM wParam, LPARAM lParam)
{

	CMYTESTADoc* pDoc = GetDocument();
	pDoc->MatFloatToCImage(pDoc->m_srcMaxValue, pDoc->m_srcMinValue);

	Invalidate();
	return 0;
}

void CMYTESTAView::OnGaosi()
{
	CMYTESTADoc* pDoc = GetDocument();
	Mat I(pDoc->m_srcRGB);

	if (I.empty())
	{
		 
		return;
	}
	float GRID_FRE = 4;			//դ��Ƶ��
	float SAMP_FRE = 7.194f;	//����Ƶ��
								//
								// CGaussianFilterProcess gfp;
	CGaussianFilterProcess gfp;
	Mat Content_image(I, Rect(20, 20, I.cols - 40, I.rows - 40));
	Mat Result_image(Content_image.rows, Content_image.cols, Content_image.type(), Scalar::all(0));	//
	gfp.Process(Content_image, Result_image, GRID_FRE, SAMP_FRE);																						///	gfp.Process(Content_image, Result_image, GRID_FRE, SAMP_FRE);
	Mat finalMat(I.rows, I.cols, I.type(), Scalar::all(0));
	Mat finalMat_ROI(finalMat, Rect(20, 20, I.cols - 40, I.rows - 40));
	Result_image.copyTo(finalMat_ROI);

	

	for (int i = 0; i < finalMat.rows; i++)
	{
		ushort *ps =  finalMat.ptr<ushort>(i);
		float *ds = pDoc->srcfloat.ptr<float>(i);
		for (int j = 0; j < finalMat.cols; j++)
		{
			ds[j] = ps[j];
		}
	}
	 pDoc->flips(pDoc->srcfloat);

	 
	// TODO: �ڴ�����������������
}

void CMYTESTAView::goback()
{
	CMYTESTADoc* pDoc = GetDocument();
	Mat I(pDoc->m_srcRGB);
	pDoc->srcfloat.release();
	pDoc->srcfloat.create(pDoc->m_srcHeight, pDoc->m_srcWidth, CV_32F);
	for (int i = 0; i < I.rows; i++)
	{
		ushort *ps = I.ptr<ushort>(i);
		float *ds = pDoc->srcfloat.ptr<float>(i);
		for (int j = 0; j < I.cols; j++)
		{
			ds[j] = ps[j];
		}
	}
	pDoc->rotatecase = 0;
	pDoc->MatFloatToCImage(pDoc->m_srcMaxValue, pDoc->m_srcMinValue);

	OnInitialUpdate();
	Invalidate();
}
 


 
 
 