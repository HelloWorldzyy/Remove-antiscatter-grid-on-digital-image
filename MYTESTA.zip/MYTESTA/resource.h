//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� MYTESTA.rc ʹ��
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define ID_INDICATOR_WIN_WIDTH          101
#define ID_INDICATOR_WIN_LEVEL          102
#define ID_INDICATOR_WIN_MIN            103
#define ID_INDICATOR_WIN_MAX            104
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MYTESTATYPE                 130
#define IDD_DIALOG_CTRLFORM             310
#define IDC_BUTTON1                     1000
#define IDC_BUTTON_OpenImage            1000
#define IDC_LITTLEBO                    1000
#define IDC_Gaosiquzao                  1001
#define IDC_Toobig                      1002
#define IDC_Toosmall                    1003
#define IDC_OpenImage                   1004
#define IDC_SCROLLBAR_TEST              1005
#define IDC_SCROLLBAR_CK                1006
#define IDC_OriginalImg                 1007
#define IDC_SaveImg                     1008
#define IDC_BUTTON2                     1009
#define IDC_OriginalImg2                1010
#define IDC_Flip                        1010
#define Waveletprocess                  32771
#define ID_BIG                          32772
#define ID_SMALL                        32773
#define Gaosi                           32774
#define IDC_SCROLLBAR_WinWidth          32775
#define IDC_EDIT1                       32776
#define IDC_SCROLLBAR2                  32777
#define IDC_EDIT2                       32778
#define IDC_CW                          32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
